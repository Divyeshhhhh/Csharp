﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace if_elseif_else
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter the number:");
            int age = Convert.ToInt32(Console.ReadLine());
            if(age>0)
            {
                if(age>=18 && age <60)
                {
                    Console.Write("adult");

                }
                else if(age<18)
                {
                    Console.Write("teenage");
                }
                else if(age>=60)
                {
                    Console.Write("senior citizen");
                }
            }
            else
            {
                Console.Write("birth panding");
            }
            Console.Read();
        }
    }
}
