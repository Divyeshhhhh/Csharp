﻿//series (for,while loop)
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace series_forloop
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter the number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, a = 2, b = 3;
            for (i = 1; i < n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i+" ");
                }
                else
                {
                    int temp = a * b;
                    if (temp > n)
                    {
                        break;
                    }
                    Console.Write(temp+" ");
                    a = b;
                    b = temp;
                }
                
            }
           
            //whileloop
            while (i < n)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                }
                else
                {
                    int temp = a * b;
                    if (temp > n)
                    {
                        break;
                    }
                    Console.Write(temp + " ");
                    a = b;
                    b = temp;
                }
                i++;
            }
            Console.Read();
        }
    }
}
